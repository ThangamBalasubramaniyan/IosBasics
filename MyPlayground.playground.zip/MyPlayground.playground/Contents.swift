import UIKit

print("Hello world")

var name: String
name = "Hello Thangam "
print(name)

var str = "hello Thangam"
// assigning a new value to str variable
str = "Welcome to Swift"
print(str)

// Constants
let item = "Table"
// Cannot assign another value to constant
//item = "chair"
print(item)

let char: Character = "w"
print(char)

let symbol: Character = "#"
print(symbol)

// Boolean
var check: Bool = true
check = false
print(check)

let floatValue: Float = 3.14
print(floatValue)

var lattitude: Double
lattitude = 14.89643690567
print(lattitude)

// compare two strings
let str1 = "Hello Thangam"
print(str == str1)
print(str1 == name)

// Join two strings
var string1 = "Hello Thangam "
var string2 = "Welcome to swift"
string1.append(string2)
print(string1)

// add strings using "+" operator
var result = name +  str
print(result)

// add strings using "+=" operator
name += str
print(string1)
// length of string
print(string1.count)
print(string2.count)
print(string1.hasSuffix("t"))

// Escape Sequence
var EscapeVariable = "This is \"Escaped String\" class."
print(EscapeVariable)

// String Interpolation
var language = "IOS development"
print("Welcome to \(language)")

// Multiline String
var multiString = """
Swift is awesome language
Swift has many features
Swift is for IOS development
"""
print(multiString)

// Print statement with separator
print("Happy New Year", 2024, "See you soon!", separator: ". ")

// Optional datatype
var optionalData: Int!
optionalData = 545
print(optionalData)
var optionalData1: Int?
print(optionalData1)

var someValue:Int? = 5
print(someValue)
print(someValue!)

//      *** Operators ***         //
// Arithmetic operator
var a = 10
var b = 7
print(a+b)
print(a-b)
print(a*b)
print(a/b)
print(a%b)

//  Assignment Operator
var x = 5
// asign addition of x and a to x
x += a
print(x)

//  Comparision Operator
print(a == b)
print(a >= b)
print(a <= b)
print(a != b)
print(a > b)
print(a < b)

// Logical Operator
// Logical AND operator
print(a>=b && a==b)

// logical OR operator
print(a>=b || a==b)

// logical NOT operator
print(!true)

//  Ternary Operator
let marks = 80
var res = (marks >= 40) ? "Pass" : "Fail"
print(res)

// Nested Ternary Operator
var results = (marks == 0) ? "Zero" : (marks >= 40) ? "Pass" : "Fail"
print(results)

//  Bitwise Operator
//  Bitwise ANd Operator
print(a & b)
print(a | b)
print(~a)
print(a ^ b)
print(a << b)
print(a >> b)

// If-else Statement
var balance = 0
if balance == 0 {
    print("Number is Zero")
} else if balance <= 0 {
    print("Number is Negative")
}else {
    print("Number is Positive")
}

//  Switch Statement
let weekOfDay = 9
switch weekOfDay {
case 1:
    print("Monday")
case 2:
    print("Tuesday")
case 3:
    print("Wednesday")
case 4:
    print("Thursday")
case 5:
    print("Friday")
case 6:
    print("Saturday")
case 7:
    print("Sunday")
default:
    print("Invalid days")
}



//    Arrays

var number = [2, 5, 7, 8, 9]
print(number)
var names: [String] = ["Thangam","Arthi","Balasubramaniyan","Bala"]
print(names)

//  Create an empty array
var value = [Int]()
print(value)

// Access array elements
print(names[0])
print(names[2])

// Add elements to an array
names.append("Thangam Balasubramaniyan")
print("After append \(names)")

// Join two Arrays
var author = ["John","Mathew","Catherine"]
names.append(contentsOf: author)
print("Join two Arrays \(names)")

// Add elements to Array specified position using Insert()
names.insert("Felix", at: 2)
print(names)

// Modify the element of an array
author[1] = "Jack"
print(author)

//  Remove an element from an array
names.remove(at: 0)
print(names)

print("Remove 1st element \(names.removeFirst())")
print("Remove last element \(names.removeLast())")
print("Remove all element \(names.removeAll())")
print(names)

// Looping through Array
let fruits = ["Apple","Orange", "Banana"]
for fruit in fruits {
    print(fruit)
}

//  Find number of Array elements
print("Number of Array elements: \(fruits.count)")

// Check empty
print(fruits.isEmpty)

// Array with mixed datatype
let mixedArray: [Any] = ["Thangam", 99]
print(mixedArray)

// Sets in Swift
var studId: Set = [10,11,12,13,14]
print(studId)

// Add element
studId.insert(15)
print(studId)

// remove element
studId.remove(10)
print(studId)

// Set operations
let setA: Set = [1, 3, 5, 6, 8,9]
let setB: Set = [2, 1, 4, 5, 6, 7, 10]
print(setA.union(setB))
print(setA.intersection(setB))
print(setB.subtracting(setA))
print(setA.symmetricDifference(setB))
print(setA.isSubset(of: setB))

//  Dictionary
var num = ["1": "One", "2": "TWo", "3": "Three"]
print(num)

// add element to dictionary
num["4"] = "Four"
print(num)

// Change value of dictionary
num["2"] = "Six"
print(num)

//  Access Keys from Dictionary
print(Array(num.keys))
// Access values from Dictionary
print(Array(num.values))

// remove element from dictionary
num.removeValue(forKey: "3")
print(num)

var emptyDictionary =  [String: Int]()
print("Empty Dictionary: ",emptyDictionary)

//  Tuple
var product = ("mac Book", 1099.78)
// access tuple elements
print(product.0)
print(product.1)

// Modify tuple elements
product.1 = 1100.99
print(product.1)

// Named Tuples
let products = (productName: "Mac Book", productPrice: 1220.98)
print(products)
print(products.productName)
print(products.productPrice)

// Nested Tuple
var alphabets = ("A", "B", "C", ("x", "y", "z"))
print(alphabets.2)
print(alphabets.3.1)

//  Dictionary inside tuple
var tupleProduct = ("mac Book", 1099.78, ["1": "One", "2": "TWo", "3": "Three"])
print(tupleProduct.2)
tupleProduct.2["4"] = "Four"
print(tupleProduct.2)

//  Functions
// Function with no parameter
func greet() {
print("Hello World!")
}
// function call
greet()

//  function with parameters
func add(num1 : Int, num2 : Int) {
    let result = num1 + num2
    print(result)
}

add(num1 : 5,num2 : 9)

//  Function return type
func findSquare (num: Int) -> Int {
  let result = num * num
  return result
}

// function call
var square = findSquare(num: 3)

print("Square:",square)

//  Swift library function

var sqaureRoot = sqrt(25)
print("square root of 25 is \(sqaureRoot)")

var power = pow(2, 6)
print(power)

//  Function with default value
func addNumbers( a: Int = 7,  b: Int = 8) {
  let sum = a + b
  print("Sum:", sum)
}

// function call with two arguments
addNumbers(a: 2, b: 3)

// function call with one argument
addNumbers(a: 2)

// function call with no arguments
addNumbers()

//  Functions with argument label
func sum(of a: Int, and b: Int) {
  print("argument label:", a + b)
}

sum(of: 2, and: 3)
// Omit argument labels
func sum(_ a: Int, _ b: Int) {
  print("Omited argument:", a + b)
}
sum(5,8)

//   Function with variadic parameters
func sums(numbers: Int...) {
    var result = 0
    for num in numbers {
        result = result + num
    }
    print("Addition of numbers: \(result)")
}

sums(numbers: 3, 5, 8, 6)

sums(numbers: 4,1,2)

// Function with inout parameters
func changeName(name: inout String) {
    if name == "Thangam" {
        name = "Thangam Balasubramaniyan"
    }
}
var userName = "Thangam"
print("before", userName)
changeName(name: &userName)
print("after", userName)

//  Mutiple return values
func compute(number: Int) -> (Int, Int, Int) {

  let square = number * number

  let cube = square * number
  
  return (number, square, cube)
}

var resultValue = compute(number: 5)

print("Numbers", resultValue.self)
print("Number:", resultValue.0)
print("Square:", resultValue.1)
print("Cube:", resultValue.2)

//   Recursion Function
func countDown(number: Int) {
    print(number)
    if number == 0 {
        print("Count down stop")
    } else {
        countDown(number: number - 1)
    }
}
print("Count Down:")
countDown(number: 4)

//   Closed Range
for numbers in 1...5 {
    print(numbers)
}

//   Half open range
for numbers in 1..<5 {
    print("Half open range: \(numbers)")
}

//  One sided range
// ..< operator
let range1 = ..<2

// check if -1 is in the range
print(range1.contains(-1))

// ... operator
let range2 = 2...

// check if 33 is in the range
print(range2.contains(33))

//   Function Overloading
// function with two parameters
func display(number1: Int, number2: Int) {
   print("1st Number: \(number1) and 2nd Number: \(number2)")
}

// function with a single parameter
func display(number: Int) {
   print("Number: \(number)")
}

// function call with single parameter
display(number: 5)

// function call with two parameters
display(number1: 6, number2: 8)

//   Closure
var closureValue = {
  print("This is Closure function")
}
// call the closure
closureValue()

//   Closure parameters
let greetUser = { (name: String)  in
    print("Hey, This is \(name).")
}

// closure call
greetUser("Thangam")

// function pass closure
func grabLunch(search: ()->()) {
  print("Let's go out for lunch")

  // closure call
  search()
}

// pass closure as a parameter
grabLunch(search: {
   print("Alfredo's Pizza: 2 miles away")
})

//     Trailing Closure
func grabLunch(message: String, search: ()->()) {
   print(message)
   search()
}

// use of trailing closure
grabLunch(message:"Let's go out for lunch")  {
  print("Alfredo's Pizza: 2 miles away")
}

//  Classes and Objects
class Bike {
    //  variables
    var name: String
    var gears: Int
    //  Static variable
    static var color: String = ""
    //   Assign values using initializer
    init(name: String, gears: Int) {
        self.name = name
        self.gears = gears
    }
}
//  Objects
var bike1 = Bike(name: "Apache", gears: 5)
//  create 2nd object
var bike2 = Bike(name: "Pulsur", gears: 6)

//  Accessing class property using objects
//  modify the name of bike
//bike1.name = "Pulsur"
//  Accessing gear property
//bike1.gears = 10
Bike.color = "Blue"
print("Colour of bike \(Bike.color)")
print("1st Name: \(bike1.name), 1st Gears: \(bike1.gears)")
//bike2.name = "Apache"
//bike2.gears = 12
print("2st Name: \(bike2.name), 2st Gears: \(bike2.gears)")

//  Proprties
class Calculator {

  // stored properties
  var num1: Int = 0
  var num2: Int = 0

  // computed property
//  var sum: Int {
//    num1 + num2
//  }
    var sum: Int {

        // retrieve value
        get {
          num1 + num2
        }
      
        // set new value to num1 and num2
        set(modify) {
          num1 = (modify + 10)
          num2 = (modify + 20)
        }
      }
    static func add(num1: Int, num2: Int) {
        print("Addition of two nos: \(num1 + num2)")
    }
    // non static method for multiply
    func multiplication() {
        print("Multiplication of two num is: \(num1 * num2)")
    }
}
var obj = Calculator()
obj.num1 = 20
obj.num2 = 50
// Method call
Calculator.add(num1: 4, num2: 6)
obj.multiplication()
// get value
print("Get value:", obj.sum)

// provide value to modify
obj.sum = 5

print("New num1 value:", obj.num1)
print("New num2 value:", obj.sum)
// read value of computed property
//print("Sum:", obj.sum)

//   Mutating methods
struct Employee {
  var salary = 0
  
  // define mutating function
    mutating func salaryIncrement(increase: Int) {

  // modify salary property
  salary = salary + increase
  print("Increased Salary:",salary)
  }
}

var employee1 = Employee()
employee1.salary = 20000
employee1.salaryIncrement(increase: 5000)

//   Parameterized Initializer
class Wall {
  
  var length: Double
    var height: Double
  // initializer with parameter
    init(length: Double, height: Double) {
        self.length = length
        self.height = height
    print("length of wall is: \(self.length)")
  }
    func calculateArea() -> Double {
        return length * height
    }
}

// create an object
var wall1 = Wall(length: 10.5, height: 8.6)
var wall2 = Wall(length: 8.5, height: 6.3)
print("area of wall1 is: ",wall1.calculateArea())
print("area of wall2 is: ",wall2.calculateArea())

//    deinitializer
class  Race {
  var laps: Int

  // define initializer
  init() {
    laps = 5
    print("Race Completed")
    print("Total laps:", laps)
  }

  // define deinitializer
  deinit {
    print("Memory Deallocated")
  }
}

// create an instance
var resultees: Race? = Race()

// deallocate object
resultees = nil

//   Swift Inheritance
class Animal {
    var name: String = ""
    
    func eat() {
        print("I can eat")
    }
}
class Dog: Animal {
    func display() {
        print("Hi, this is",name)
    }
    // override method
    override func eat() {
        //  Call method from super class using super keyword
        super.eat()
        print("I can eat dog food")
    }
}
var breed = Dog()
breed.name = "labrador"
breed.eat()

breed.display()

//    Protocol
protocol Greet {
  // blueprint of property
    var name: String { get }
  // blueprint of a method
  func message()
}

// conform class to Greet protocol
class Employees: Greet {

  // implementation of property
  var name = "Thangam"

  // implementation of method
  func message() {
    print("Good Morning", name)
  }
}

var employees = Employees()
employees.message()

//  Multiple protocols
// Sum protocol
protocol Sum {

  func addition()
}

// Multiplication protocol
protocol Multiplication {

  func product()
}

// conform class to two protocols
class Calculate: Sum, Multiplication {

  var num1 = 0
  var num2 = 0

  func addition () {
    let result1 = num1 + num2
    print("Sum:", result1)
  }

  func product () {
    let result2 = num1 * num2
    print("Product:", result2)
  }
                   
}
var calculate1 = Calculate()

// assign values to properties
calculate1.num1 = 5
calculate1.num2 = 10

// access methods
calculate1.addition()
calculate1.product()

//    Enum
enum Season: CaseIterable {
  
  // define enum values
  case spring, summer, autumn, winter
}

// create enum variable
var currentSeason: Season

// for loop to iterate over all cases
for currentSeason in Season.allCases {
  print(currentSeason)
}
// assign value to enum variable
currentSeason = Season.summer

print("Current Season:", currentSeason)

// enum with raw values
enum Size : Int {
  case small = 10
  case medium = 12
  case large = 14
}

// access raw value
var output = Size.small.rawValue
print(output)

//   Struct
struct Person {

// define two properties
 var name = ""
 var age = 0
}

// create instance of Person
var person1 = Person()

// access properties and assign new values
person1.age = 21
person1.name = "Thangam"

print("Name: \(person1.name) and Age: \( person1.age) ")

//   Singleton
class FileManager{
 // create a singleton
 static let fileObj = FileManager()
 // create a private initializer
private init() {
  
}

 // method to request file
func checkFileAccess(user: String) {

  // condition to check username
  if user == ("Thangam") {

    print("Access Granted")
  }

  else {
    print(" Access Denied")
  }
}
}

let userName1 = "Thangam"

// access method
let file = FileManager.fileObj

file.checkFileAccess(user: userName1)

